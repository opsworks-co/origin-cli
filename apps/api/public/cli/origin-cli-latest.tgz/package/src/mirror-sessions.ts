import fs from 'fs';
import path from 'path';
import os from 'os';

const MIRROR_DIR = path.join(os.homedir(), '.origin', 'mirrors');

export interface MirrorEntry {
  profile: string;
  apiUrl: string;
  apiKey: string;
  sessionId: string;
}

function ensureDir() {
  if (!fs.existsSync(MIRROR_DIR)) {
    fs.mkdirSync(MIRROR_DIR, { recursive: true, mode: 0o700 });
  }
}

function pathFor(primarySessionId: string): string {
  // sessionId is server-issued (ulid/uuid); restrict to safe chars to keep
  // paths sane even if the server format ever changes.
  const safe = primarySessionId.replace(/[^A-Za-z0-9._-]/g, '_');
  return path.join(MIRROR_DIR, `${safe}.json`);
}

export function writeMirrors(primarySessionId: string, mirrors: MirrorEntry[]): void {
  if (mirrors.length === 0) return;
  ensureDir();
  const file = pathFor(primarySessionId);
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify({ mirrors }, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, file);
}

export function readMirrors(primarySessionId: string): MirrorEntry[] {
  try {
    const raw = fs.readFileSync(pathFor(primarySessionId), 'utf-8');
    const parsed = JSON.parse(raw);
    if (!parsed || !Array.isArray(parsed.mirrors)) return [];
    return parsed.mirrors.filter((m: any) => m && m.apiUrl && m.apiKey && m.sessionId);
  } catch {
    return [];
  }
}

export function deleteMirrors(primarySessionId: string): void {
  try {
    fs.unlinkSync(pathFor(primarySessionId));
  } catch { /* ignore */ }
}
