import { loadConfig, loadSecondaryProfiles } from './config.js';
import { writeMirrors, readMirrors, deleteMirrors, type MirrorEntry } from './mirror-sessions.js';

function getConfig() {
  const config = loadConfig();
  if (!config) throw new Error('Not logged in. Run: origin login');
  return config;
}

// Issue the same request against a non-primary profile. Used to mirror
// session-lifecycle writes so every logged-in account gets its own copy of
// the session record. Mirror failures are swallowed — primary already
// succeeded, mirror loss is an at-most-once degradation, not a hard fail.
async function requestProfile(
  profile: { apiUrl: string; apiKey: string; name?: string },
  path: string,
  opts: RequestInit = {},
): Promise<any | null> {
  try {
    const res = await fetch(`${profile.apiUrl}${path}`, {
      ...opts,
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': profile.apiKey,
        ...opts.headers as Record<string, string>,
      },
    });
    if (!res.ok) {
      if (process.env.ORIGIN_DEBUG) {
        const body = await res.text().catch(() => '');
        console.error(`[origin] mirror ${profile.name || profile.apiUrl} ${path} failed: ${res.status} ${body.slice(0, 200)}`);
      }
      return null;
    }
    return await res.json().catch(() => null);
  } catch (err: any) {
    if (process.env.ORIGIN_DEBUG) {
      console.error(`[origin] mirror ${profile.name || profile.apiUrl} ${path} error: ${err?.message || err}`);
    }
    return null;
  }
}

// Fan out a per-mirror request. Each mirror gets its own session id baked
// into the URL via `pathFor(mirror.sessionId)`. Runs in parallel; never
// throws.
async function fanOutMirrors(
  primarySessionId: string,
  pathFor: (mirrorSessionId: string) => string,
  opts: RequestInit = {},
  bodyTransform?: (mirrorSessionId: string) => any,
): Promise<void> {
  const mirrors = readMirrors(primarySessionId);
  if (mirrors.length === 0) return;
  await Promise.all(mirrors.map((m) => {
    const reqOpts = bodyTransform
      ? { ...opts, body: JSON.stringify(bodyTransform(m.sessionId)) }
      : opts;
    return requestProfile(m, pathFor(m.sessionId), reqOpts);
  }));
}

/** Ensure a parsed API response is a non-null object. */
function assertObj(res: unknown, label: string): asserts res is Record<string, unknown> {
  if (!res || typeof res !== 'object' || Array.isArray(res)) {
    throw new Error(`Invalid API response for ${label}: expected object, got ${res === null ? 'null' : typeof res}`);
  }
}

/** Ensure a parsed API response is a non-null object with specific required fields. */
function assertFields(res: unknown, label: string, fields: string[]): asserts res is Record<string, unknown> {
  assertObj(res, label);
  for (const f of fields) {
    if ((res as Record<string, unknown>)[f] === undefined) {
      throw new Error(`Invalid API response for ${label}: missing required field '${f}'`);
    }
  }
}

async function request(path: string, opts: RequestInit = {}) {
  const config = getConfig();
  const res = await fetch(`${config.apiUrl}${path}`, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': config.apiKey,
      ...opts.headers as Record<string, string>,
    },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({})) as any;
    const err = new Error(body?.message || body?.error || res.statusText) as any;
    err.status = res.status;
    err.serverError = body?.error;
    err.serverMessage = body?.message;
    // Whole body for callers that want to read structured fields like the
    // budget-block `level` (model | agent | user-model | repo-model | org).
    err.serverBody = body;
    throw err;
  }
  return res.json();
}

export const api = {
  getPolicies: () => request('/api/mcp/policies'),
  registerMachine: (data: any) => request('/api/machines', { method: 'POST', body: JSON.stringify(data) }),
  getMachines: () => request('/api/machines'),
  syncRepo: (id: string) => request(`/api/repos/${id}/sync`, { method: 'POST' }),
  getRepos: () => request('/api/repos'),
  getWhoami: () => request('/api/mcp/whoami'),
  getMe: async () => {
    const res = await request('/api/auth/me');
    assertObj(res, 'getMe');
    return res;
  },

  // Session lifecycle (MCP API — used by hooks)
  // All session-write endpoints fan out to every secondary profile so each
  // logged-in account ends up with its own session record. Primary owns
  // the canonical sessionId returned to the caller; mirror sessionIds are
  // stashed in ~/.origin/mirrors/<primaryId>.json and consulted by the
  // other endpoints below.
  startSession: async (data: {
    machineId: string;
    prompt: string;
    model: string;
    repoPath: string;
    repoUrl?: string;
    agentSlug?: string;
    branch?: string;
    hostname?: string;
    additionalRepoPaths?: string[];
    agentSessionId?: string;
  }) => {
    const res = await request('/api/mcp/session/start', { method: 'POST', body: JSON.stringify(data) });
    assertFields(res, 'startSession', ['sessionId']);
    const primaryId = (res as any).sessionId as string;

    const secondaries = loadSecondaryProfiles();
    if (secondaries.length > 0) {
      const results = await Promise.all(secondaries.map(async (p) => {
        const r = await requestProfile(p, '/api/mcp/session/start', {
          method: 'POST',
          body: JSON.stringify(data),
        });
        if (r && typeof r === 'object' && typeof r.sessionId === 'string') {
          return { profile: p.name, apiUrl: p.apiUrl, apiKey: p.apiKey, sessionId: r.sessionId } as MirrorEntry;
        }
        return null;
      }));
      const mirrors = results.filter((m): m is MirrorEntry => m !== null);
      writeMirrors(primaryId, mirrors);
    }
    return res;
  },
  updateSession: async (id: string, data: any) => {
    const res = await request(`/api/mcp/session/${id}`, { method: 'PATCH', body: JSON.stringify(data) });
    assertObj(res, 'updateSession');
    fanOutMirrors(id, (mid) => `/api/mcp/session/${mid}`, { method: 'PATCH', body: JSON.stringify(data) }).catch(() => {});
    return res;
  },
  resumeSession: async (id: string) => {
    const res = await request(`/api/mcp/session/${id}/resume`, { method: 'POST' });
    assertObj(res, 'resumeSession');
    fanOutMirrors(id, (mid) => `/api/mcp/session/${mid}/resume`, { method: 'POST' }).catch(() => {});
    return res;
  },
  endSession: async (data: any) => {
    const res = await request('/api/mcp/session/end', { method: 'POST', body: JSON.stringify(data) });
    assertObj(res, 'endSession');
    const primaryId = data?.sessionId as string | undefined;
    if (primaryId) {
      // Mirror /session/end takes sessionId in the body — swap it per mirror.
      await fanOutMirrors(
        primaryId,
        () => '/api/mcp/session/end',
        { method: 'POST' },
        (mid) => ({ ...data, sessionId: mid }),
      );
      deleteMirrors(primaryId);
    }
    return res;
  },
  pingSession: (id: string) => {
    fanOutMirrors(id, (mid) => `/api/mcp/session/${mid}/ping`, { method: 'POST' }).catch(() => {});
    return request(`/api/mcp/session/${id}/ping`, { method: 'POST' });
  },
  ingestCommits: async (data: {
    repoPath: string;
    repoUrl?: string;
    commits: Array<{
      sha: string;
      message?: string;
      author?: string;
      branch?: string | null;
      filesChanged?: string[];
      additions?: number;
      deletions?: number;
      committedAt?: string;
    }>;
  }) => {
    const res = await request('/api/mcp/commits/ingest', { method: 'POST', body: JSON.stringify(data) });
    assertObj(res, 'ingestCommits');
    // No sessionId scoping — fan out to every secondary profile so each
    // org sees commits for the same repo path.
    const secondaries = loadSecondaryProfiles();
    if (secondaries.length > 0) {
      Promise.all(secondaries.map((p) =>
        requestProfile(p, '/api/mcp/commits/ingest', { method: 'POST', body: JSON.stringify(data) })
      )).catch(() => {});
    }
    return res;
  },
  attachRepo: async (id: string, repoPath: string) => {
    const res = await request(`/api/mcp/session/${id}/attach-repo`, {
      method: 'POST',
      body: JSON.stringify({ repoPath }),
    });
    assertObj(res, 'attachRepo');
    fanOutMirrors(id, (mid) => `/api/mcp/session/${mid}/attach-repo`, {
      method: 'POST',
      body: JSON.stringify({ repoPath }),
    }).catch(() => {});
    return res;
  },
  uploadSnapshot: async (id: string, snapshot: {
    snapshotId: string;
    type: string;
    takenAt: string;
    promptIndex?: number | null;
    commitSha?: string | null;
    treeSha?: string | null;
    filesChanged?: string[];
    linesAdded?: number;
    linesRemoved?: number;
  }) => {
    const res = await request(`/api/mcp/session/${id}/snapshot`, {
      method: 'POST',
      body: JSON.stringify(snapshot),
    });
    assertObj(res, 'uploadSnapshot');
    fanOutMirrors(id, (mid) => `/api/mcp/session/${mid}/snapshot`, {
      method: 'POST',
      body: JSON.stringify(snapshot),
    }).catch(() => {});
    return res;
  },

  // Sessions (web API)
  getSessions: (params?: Record<string, string>) => {
    const q = new URLSearchParams(params).toString();
    return request(`/api/sessions${q ? `?${q}` : ''}`);
  },
  getSession: async (id: string) => {
    const res = await request(`/api/sessions/${id}`);
    assertObj(res, 'getSession');
    return res;
  },
  reviewSession: (id: string, status: string, note?: string) =>
    request(`/api/sessions/${id}/review`, { method: 'POST', body: JSON.stringify({ status, note }) }),
  shareSession: (id: string) =>
    request(`/api/sessions/${id}/share`, { method: 'POST' }),
  endSessionById: (id: string) =>
    request(`/api/sessions/${id}/end`, { method: 'POST' }),

  // Agents
  getMyAgents: () => request('/api/agents/my'),
  getAgents: () => request('/api/agents'),
  getAgent: (id: string) => request(`/api/agents/${id}`),
  createAgent: (data: any) => request('/api/agents', { method: 'POST', body: JSON.stringify(data) }),
  updateAgent: (id: string, data: any) => request(`/api/agents/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteAgent: (id: string) => request(`/api/agents/${id}`, { method: 'DELETE' }),

  // Repos
  createRepo: (data: any) => request('/api/repos', { method: 'POST', body: JSON.stringify(data) }),
  deleteRepo: (id: string) => request(`/api/repos/${id}`, { method: 'DELETE' }),

  // Policies (CRUD)
  createPolicy: (data: any) => request('/api/policies', { method: 'POST', body: JSON.stringify(data) }),
  deletePolicy: (id: string) => request(`/api/policies/${id}`, { method: 'DELETE' }),

  // PR Review (CLI)
  reviewPR: (url: string) => request(`/api/pull-requests/review?url=${encodeURIComponent(url)}`),

  // Audit
  getAuditLogs: (params?: Record<string, string>) => {
    const q = new URLSearchParams(params).toString();
    return request(`/api/audit${q ? `?${q}` : ''}`);
  },

  // Stats
  getStats: async (params?: Record<string, string>) => {
    const q = new URLSearchParams(params).toString();
    const res = await request(`/api/stats${q ? `?${q}` : ''}`);
    assertObj(res, 'getStats');
    return res;
  },

  // Versioning
  getPolicyVersions: (id: string) => request(`/api/policies/${id}/versions`),
  getAgentVersions: (id: string) => request(`/api/agents/${id}/versions`),

  // Notifications
  getNotifications: (params?: Record<string, string>) => {
    const q = new URLSearchParams(params).toString();
    return request(`/api/notifications${q ? `?${q}` : ''}`);
  },
  getUnreadCount: () => request('/api/notifications/unread-count'),
  markAllRead: () => request('/api/notifications/read-all', { method: 'PUT' }),

  // Users / Team
  getUsers: () => request('/api/users'),
  getUser: (id: string) => request(`/api/users/${id}`),

  // Pricing
  getPricing: async () => {
    const res = await request('/api/pricing');
    assertObj(res, 'getPricing');
    return res;
  },

  // Secret findings (pre-commit hook)
  reportSecrets: (sessionId: string, findings: any[]) => {
    fanOutMirrors(sessionId, (mid) => `/api/sessions/${mid}/secrets`, {
      method: 'POST',
      body: JSON.stringify({ findings, source: 'pre-commit' }),
    }).catch(() => {});
    return request(`/api/sessions/${sessionId}/secrets`, {
      method: 'POST',
      body: JSON.stringify({ findings, source: 'pre-commit' }),
    });
  },

  reportViolation: (data: { machineId: string; policyId: string; description: string; filepath?: string }) =>
    request('/api/mcp/violations', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
};
