import chalk from 'chalk';
import { loadConfig, loadAgentConfig, loadRepoConfig, listProfiles } from '../config.js';
import { api } from '../api.js';
import { loadSessionState, listActiveSessions, getGitRoot, getBranch, getHeadSha } from '../session-state.js';
import { git, gitDetailed } from '../utils/exec.js';

const HEX = /^[a-fA-F0-9]{4,64}$/;

function formatDuration(ms: number): string {
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  const rem = s % 60;
  if (m < 60) return `${m}m ${rem}s`;
  const h = Math.floor(m / 60);
  return `${h}h ${m % 60}m`;
}

export async function statusCommand() {
  const config = loadConfig();
  const agentConfig = loadAgentConfig();

  console.log(chalk.bold('\n  Origin Status\n'));

  // Mode status
  const connected = config?.mode !== 'standalone' && config?.apiKey && config?.apiUrl;
  const isSolo = config?.keyType === 'solo' || config?.accountType === 'developer';

  // Compute multi-account state up front so the connected header reflects
  // it instead of burying it in a separate "Accounts" section at the bottom.
  const allProfiles = listProfiles();
  const multiAccount = connected && allProfiles.length > 1;

  if (config?.mode === 'standalone') {
    console.log(chalk.yellow('  ⚡ Standalone mode (forced)'));
    console.log(chalk.gray('    Sessions tracked locally in git notes'));
    console.log(chalk.gray('    Run `origin config set mode auto` to reconnect'));
  } else if (multiAccount) {
    // Multi-account: list every profile inline at the top, with the
    // primary's scope details from /whoami. Sessions fan out to all.
    const modes = Array.from(new Set(allProfiles.map(p => p.accountType === 'developer' ? 'solo' : 'team')));
    console.log(chalk.green(`  ✅ Connected · ${allProfiles.length} accounts (${modes.join(' + ')})`));
    let primaryScope = '';
    try {
      const data = await api.getWhoami() as any;
      const repoLabel = data.repoScopes?.length > 0 ? `${data.repoScopes.length} repos` : `${data.repoCount || 0} repos`;
      const agentLabel = data.agentScopes?.length > 0 ? `${data.agentScopes.length} agents` : `${data.agentCount || 0} agents`;
      primaryScope = ` · ${repoLabel} · ${agentLabel}`;
    } catch { /* primary scope unavailable, skip */ }
    for (const p of allProfiles) {
      const isActive = p.apiKey === config?.apiKey;
      const indicator = isActive ? chalk.white('●') : chalk.gray('○');
      const mode = p.accountType === 'developer' ? chalk.green('solo') : chalk.blue('team');
      const orgLabel = p.accountType === 'developer'
        ? `Solo Developer${p.orgName ? ` @ ${p.orgName}` : ''}`
        : `Team Member @ ${p.orgName || 'unknown'}`;
      const scopeSuffix = isActive ? primaryScope : '';
      const line = `${p.name} (${mode}) → ${orgLabel}${scopeSuffix}`;
      console.log(`    ${indicator} ${isActive ? chalk.white(line) : chalk.gray(line)}`);
    }
    console.log(chalk.gray('    Sessions sent to all accounts in parallel'));
  } else if (connected && isSolo) {
    console.log(chalk.green('  ✅ Connected · Solo Developer'));
    console.log(chalk.gray(`    📦 Personal workspace · All repos · All agents`));
  } else if (connected) {
    const orgName = config.orgName || config.orgId || 'unknown';
    console.log(chalk.green(`  ✅ Connected · Team Member @ ${orgName}`));
    // Fetch live scope info
    try {
      const data = await api.getWhoami() as any;
      const repoLabel = data.repoScopes?.length > 0 ? `${data.repoScopes.length} repos` : `${data.repoCount || 0} repos`;
      const agentLabel = data.agentScopes?.length > 0 ? `${data.agentScopes.length} agents` : `${data.agentCount || 0} agents`;
      console.log(chalk.gray(`    📦 ${repoLabel} · ${agentLabel}`));
    } catch {
      console.log(chalk.gray(`    API: ${config.apiUrl}`));
    }
  } else {
    console.log(chalk.green('  ✓ Standalone mode'));
    console.log(chalk.gray('    Sessions tracked locally in git notes'));
    console.log(chalk.gray('    Run `origin login` to connect to Origin platform'));
  }

  // Agent status
  if (!agentConfig) {
    console.log(chalk.yellow('\n  ⚠ Agent not initialized'));
    console.log(chalk.gray('    Run: origin init'));
  } else {
    console.log(chalk.green('\n  ✓ Agent initialized'));
    console.log(chalk.gray(`    Machine: ${agentConfig.hostname} (${agentConfig.machineId.slice(0, 8)}...)`));
    console.log(chalk.gray(`    Tools: ${agentConfig.detectedTools.length > 0 ? agentConfig.detectedTools.join(', ') : 'none'}`));
  }

  // ── Active Sessions ─────────────────────────────────────────────
  const cwd = process.cwd();
  const repoPath = getGitRoot(cwd);
  const activeSessions = listActiveSessions(cwd);

  if (activeSessions.length > 0) {
    const label = activeSessions.length === 1 ? 'Active Session' : `Active Sessions (${activeSessions.length})`;
    console.log(chalk.magenta(`\n  ● ${label}`));

    for (const state of activeSessions) {
      const durationMs = Date.now() - new Date(state.startedAt).getTime();
      const branch = state.branch || getBranch(cwd);
      const headSha = getHeadSha(cwd);

      if (activeSessions.length > 1) {
        console.log(chalk.gray('    ─────────────────────────────'));
      }
      console.log(chalk.gray(`    Session ID:  ${chalk.white(state.sessionId)}`));
      console.log(chalk.gray(`    Model:       ${chalk.cyan(state.model)}`));
      console.log(chalk.gray(`    Duration:    ${chalk.white(formatDuration(durationMs))}`));
      if (branch) {
        console.log(chalk.gray(`    Branch:      ${chalk.yellow(branch)}`));
      }
      if (headSha) {
        console.log(chalk.gray(`    HEAD:        ${chalk.white(headSha.slice(0, 8))}`));
      }
      if (state.headShaAtStart) {
        console.log(chalk.gray(`    Start HEAD:  ${chalk.white(state.headShaAtStart.slice(0, 8))}`));
      }
      console.log(chalk.gray(`    Prompts:     ${chalk.white(String(state.prompts.length))}`));
      console.log(chalk.gray(`    Repo:        ${chalk.white(state.repoPath)}`));

      if (state.transcriptPath) {
        console.log(chalk.gray(`    Transcript:  ${chalk.white(state.transcriptPath)}`));
      }

      // Show new commits since session started
      if (state.headShaAtStart && headSha && state.headShaAtStart !== headSha) {
        try {
          if (HEX.test(state.headShaAtStart) && HEX.test(headSha)) {
            const commitCount = git(
              ['rev-list', '--count', `${state.headShaAtStart}..${headSha}`],
              { cwd: repoPath || cwd }
            ).trim();
            console.log(chalk.gray(`    New commits: ${chalk.green(commitCount)}`));
          }
        } catch { /* ignore */ }
      }

      // Origin dashboard link
      const apiUrl = config?.apiUrl || 'https://getorigin.io';
      console.log(chalk.gray(`    Dashboard:   ${chalk.blue(`${apiUrl}/sessions/${state.sessionId}`)}`));
    }
  } else if (repoPath) {
    console.log(chalk.gray('\n  No active session in this repo'));
  }

  // ── Repo Context ────────────────────────────────────────────────
  if (repoPath) {
    const repoConfig = loadRepoConfig(repoPath);
    const branch = getBranch(cwd);

    console.log(chalk.bold('\n  Repository'));
    console.log(chalk.gray(`    Path:        ${chalk.white(repoPath)}`));
    if (branch) {
      console.log(chalk.gray(`    Branch:      ${chalk.yellow(branch)}`));
    }
    if (repoConfig?.agent) {
      console.log(chalk.gray(`    Agent link:  ${chalk.cyan(repoConfig.agent)}`));
    }

    // Check for origin-sessions branch (entrypoints)
    try {
      const r = gitDetailed(['log', 'origin-sessions', '--oneline'], { cwd: repoPath });
      if (r.status === 0) {
        const count = r.stdout.split('\n').filter(Boolean).length;
        if (count > 0) {
          console.log(chalk.gray(`    Entrypoints: ${chalk.green(String(count))} sessions on origin-sessions branch`));
        }
      }
    } catch { /* ignore */ }

    // Check for git notes
    try {
      const r = gitDetailed(['notes', '--ref=origin', 'list'], { cwd: repoPath });
      if (r.status === 0) {
        const count = r.stdout.split('\n').filter(Boolean).length;
        if (count > 0) {
          console.log(chalk.gray(`    Git notes:   ${chalk.green(String(count))} commits annotated`));
        }
      }
    } catch { /* ignore */ }
  }

  // ── Policies & API Health (connected mode only) ────────────────
  if (connected) {
    try {
      const data = await api.getPolicies() as any;
      const policies = data.policies ?? data;
      const count = Array.isArray(policies) ? policies.length : 0;
      console.log(chalk.green(`\n  ✓ ${count} active ${count === 1 ? 'policy' : 'policies'}`));
    } catch (err: any) {
      console.log(chalk.yellow(`\n  ⚠ Could not fetch policies: ${err.message}`));
    }

    try {
      const res = await fetch(`${config!.apiUrl}/api/mcp/policies`, {
        headers: { 'X-API-Key': config!.apiKey },
      });
      if (res.ok) {
        console.log(chalk.green('  ✓ API connection healthy'));
      } else {
        console.log(chalk.red(`  ✗ API returned ${res.status}`));
      }
    } catch {
      console.log(chalk.red('  ✗ Cannot reach Origin API'));
    }
  }

  // ── Single-account fallback ─────────────────────────────────────
  // Multi-account state is rendered inline at the top now. Only show this
  // section when there's exactly one profile and it differs from primary
  // (rare, but possible after a manual profile edit).
  if (!multiAccount && allProfiles.length === 1 && connected) {
    const p = allProfiles[0];
    if (p.apiKey !== config?.apiKey) {
      console.log(chalk.bold('\n  Account'));
      const mode = p.accountType === 'developer' ? chalk.green('solo') : chalk.blue('team');
      console.log(`    ${chalk.gray('○')} ${chalk.gray(`${p.name} (${mode}) → ${p.orgName}`)}`);
    }
  }

  console.log('');
}
