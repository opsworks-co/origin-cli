import chalk from 'chalk';
import fs from 'fs';
import { git, gitDetailed } from '../utils/exec.js';
import { getGitRoot } from '../session-state.js';

const SAFE_ID = /^[a-zA-Z0-9_.-]+$/;

interface ExportSession {
  sessionId: string;
  model: string;
  startedAt: string;
  endedAt: string;
  status: string;
  durationMs: number;
  costUsd: number;
  tokensUsed: number;
  linesAdded: number;
  linesRemoved: number;
  filesCount: number;
  filesChanged: string[];
  branch: string;
}

function listLocalSessions(repoPath: string): ExportSession[] {
  const gitOpts = { cwd: repoPath };
  const sessions: ExportSession[] = [];

  {
    const r = gitDetailed(['rev-parse', 'refs/heads/origin-sessions'], gitOpts);
    if (r.status !== 0) return sessions;
  }

  try {
    const raw = git(['ls-tree', '--name-only', 'origin-sessions', 'sessions/'], gitOpts).trim();
    if (!raw) return sessions;

    const dirs = raw.split('\n').filter(Boolean).map(d => d.replace('sessions/', ''));

    for (const dir of dirs) {
      if (!SAFE_ID.test(dir)) continue;
      try {
        const metadataJson = git(['show', `origin-sessions:sessions/${dir}/metadata.json`], gitOpts).trim();
        const m = JSON.parse(metadataJson);
        sessions.push({
          sessionId: m.sessionId || dir,
          model: m.model || 'unknown',
          startedAt: m.startedAt || '',
          endedAt: m.endedAt || '',
          status: m.status || 'ended',
          durationMs: m.durationMs || 0,
          costUsd: m.cost?.usd || 0,
          tokensUsed: m.tokens?.total || 0,
          linesAdded: m.lines?.added || 0,
          linesRemoved: m.lines?.removed || 0,
          filesCount: (m.filesChanged || []).length,
          filesChanged: m.filesChanged || [],
          branch: m.git?.branch || '',
        });
      } catch { /* skip */ }
    }
  } catch { /* no sessions */ }

  sessions.sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime());
  return sessions;
}

function toCsv(sessions: ExportSession[]): string {
  const headers = ['sessionId', 'model', 'startedAt', 'endedAt', 'status', 'durationMs', 'costUsd', 'tokensUsed', 'linesAdded', 'linesRemoved', 'filesCount', 'branch'];
  const lines = [headers.join(',')];

  for (const s of sessions) {
    const row = [
      s.sessionId,
      csvEscape(s.model),
      s.startedAt,
      s.endedAt,
      s.status,
      String(s.durationMs),
      s.costUsd.toFixed(4),
      String(s.tokensUsed),
      String(s.linesAdded),
      String(s.linesRemoved),
      String(s.filesCount),
      csvEscape(s.branch),
    ];
    lines.push(row.join(','));
  }

  return lines.join('\n') + '\n';
}

function csvEscape(value: string): string {
  if (value.includes(',') || value.includes('"') || value.includes('\n')) {
    return '"' + value.replace(/"/g, '""') + '"';
  }
  return value;
}

export async function exportCommand(opts?: { format?: string; output?: string; limit?: string; model?: string; session?: string }) {
  const cwd = process.cwd();
  const repoPath = getGitRoot(cwd);
  if (!repoPath) {
    console.error(chalk.red('Error: Not in a git repository.'));
    return;
  }

  // Handle agent-trace format separately
  const format = (opts?.format || 'json').toLowerCase();
  if (format === 'agent-trace') {
    const { exportAgentTrace } = await import('../agent-trace.js');
    const trace = exportAgentTrace(repoPath, opts?.session);
    const output = JSON.stringify(trace, null, 2) + '\n';

    if (opts?.output) {
      fs.writeFileSync(opts.output, output);
      console.error(chalk.green(`  Exported Agent Trace v0.1.0 (${trace.files.length} files) to ${opts.output}`));
    } else {
      process.stdout.write(output);
    }
    return;
  }

  let sessions = listLocalSessions(repoPath);

  if (sessions.length === 0) {
    console.error(chalk.gray('No sessions found. Start an AI coding session to begin tracking.'));
    return;
  }

  // Apply filters
  if (opts?.model) {
    const m = opts.model.toLowerCase();
    sessions = sessions.filter(s => s.model.toLowerCase().includes(m));
  }
  if (opts?.limit) {
    const n = parseInt(opts.limit, 10);
    if (n > 0) sessions = sessions.slice(0, n);
  }

  // Format output
  let output: string;

  if (format === 'csv') {
    output = toCsv(sessions);
  } else {
    output = JSON.stringify(sessions, null, 2) + '\n';
  }

  // Write to file or stdout
  if (opts?.output) {
    fs.writeFileSync(opts.output, output);
    console.error(chalk.green(`  Exported ${sessions.length} session${sessions.length !== 1 ? 's' : ''} to ${opts.output}`));
  } else {
    process.stdout.write(output);
  }
}
